import React from "react";
import Ipod from "./Ipod";

function App() {
  return (
    <div className="App">
      <Ipod />
    </div>
  );
}

export default App;
